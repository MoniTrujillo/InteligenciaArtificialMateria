"""
Análisis del corpus "comentarios_no_todos_pueden_votar.csv"
1) Exploración del CSV
2) Análisis de palabras (corpus)
3) Puntaje heurístico de sospecha de bot (no hay etiqueta real de bot en los datos)
4) Argumentos a favor / en contra de que todos voten, sustentados con frecuencias

Uso: python3 analisis_bots_votacion.py comentarios_no_todos_pueden_votar.csv
"""
import re
import sys
from collections import Counter

import pandas as pd

ruta = sys.argv[1] if len(sys.argv) > 1 else "comentarios_no_todos_pueden_votar.csv"
df = pd.read_csv(ruta)

# ---------------------------------------------------------------- 1. Exploración
print("Filas:", len(df), "| Usuarios únicos:", df.usuario.nunique())
print("Comentarios distintos (texto exacto):", df.comentario.nunique())

# Texto base: quitamos hashtags, 'pls' y signos repetidos para ver la plantilla
df["texto_base"] = (
    df.comentario.str.lower()
    .str.replace(r"(#\w+|\bpls\b|\?+|\.+|!+)", "", regex=True)
    .str.strip()
)
print("Frases base distintas:", df.texto_base.nunique())
for col in ["categoria", "sentimiento", "puede_votar", "cuenta_verificada", "voto"]:
    print(f"\n{col}\n", df[col].value_counts().to_string())

# ---------------------------------------------------------------- 2. Corpus de palabras
STOP = set(
    "de la el que y a en no los las por para se me mi con es si un una lo al del más "
    "su ya hay qué o sí te mi aquí así esta este".split()
)


def tokens(t):
    return [w for w in re.findall(r"[a-záéíóúñü0-9]+", t.lower()) if w not in STOP]


freq_total = Counter(w for t in df.comentario for w in tokens(t))
print("\nTop 30 palabras:", freq_total.most_common(30))

# Palabras por grupo de posición
for cat in ["a_favor_restriccion", "en_contra_restriccion", "queja"]:
    f = Counter(w for t in df[df.categoria == cat].comentario for w in tokens(t))
    print(f"\nTop palabras [{cat}]:", f.most_common(12))

# Léxico relacionado con bots/seguridad vs derechos/justicia
LEX_SEGURIDAD = {"bot", "bots", "manipulan", "falsos", "seguridad", "protege", "filtro", "verificación", "verificadas", "reales"}
LEX_DERECHOS = {"justo", "antidemocrático", "discrimina", "silencia", "legítima", "válida", "todos", "absurdo", "pago"}
df["lex_seguridad"] = df.comentario.apply(lambda t: any(w in LEX_SEGURIDAD for w in tokens(t)))
df["lex_derechos"] = df.comentario.apply(lambda t: any(w in LEX_DERECHOS for w in tokens(t)))

# ---------------------------------------------------------------- 3. Puntaje de sospecha de bot
dup_exacto = df.comentario.value_counts()
df["veces_texto_exacto"] = df.comentario.map(dup_exacto)
# Mismo texto exacto publicado por cuentas creadas el mismo día -> posible coordinación
grupo = df.groupby(["dias_cuenta", "comentario"]).usuario.transform("count")
df["clon_mismo_dia"] = grupo > 1


def puntaje(r):
    s = 0
    motivos = []
    if r.dias_cuenta == 1:
        s += 35; motivos.append("cuenta de 1 día (pico de creación)")
    elif r.dias_cuenta <= 7:
        s += 25; motivos.append("cuenta ≤7 días")
    elif r.dias_cuenta <= 30:
        s += 15; motivos.append("cuenta ≤30 días")
    if r.cuenta_verificada == 0:
        s += 25; motivos.append("no verificada")
    if r.clon_mismo_dia:
        s += 20; motivos.append("texto idéntico a otra cuenta creada el mismo día")
    if r.veces_texto_exacto >= 8:
        s += 10; motivos.append("texto exacto repetido ≥8 veces")
    if r.puede_votar == 1 and r.dias_cuenta <= 30:
        s += 10; motivos.append("vota pese a no cumplir antigüedad")
    return pd.Series({"puntaje_bot": min(s, 100), "motivos": "; ".join(motivos)})


df[["puntaje_bot", "motivos"]] = df.apply(puntaje, axis=1)
df["clasificacion"] = pd.cut(
    df.puntaje_bot, [-1, 34, 59, 100], labels=["probable_humano", "sospechoso", "probable_bot"]
)
print("\nClasificación:\n", df.clasificacion.value_counts().to_string())
print(pd.crosstab(df.clasificacion, df.categoria))
print(pd.crosstab(df.clasificacion, df.puede_votar))

# ---------------------------------------------------------------- 4. ¿Todos deben votar?
votantes = df[df.puede_votar == 1]
print("\nVotos emitidos:\n", votantes.voto.value_counts().to_string())
print("\nPosición por grupo (categoría, % por columna):")
print((pd.crosstab(df.categoria, df.puede_votar, normalize="columns") * 100).round(1))
print("\nLéxico seguridad vs derechos por puede_votar (%):")
print((df.groupby("puede_votar")[["lex_seguridad", "lex_derechos"]].mean() * 100).round(1))

salida = df.drop(columns=["texto_base"])
salida.to_csv("comentarios_clasificados_bots.csv", index=False, encoding="utf-8-sig")
print("\nGuardado: comentarios_clasificados_bots.csv")
